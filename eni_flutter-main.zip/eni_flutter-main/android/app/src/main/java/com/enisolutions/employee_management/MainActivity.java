package com.enisolutions.employee_management;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
