class ApiConstants {
  static String baseUrl = 'https://enisolution.com:5000/employ';
  static String gteEmpEndPoint = '/Employ/';
  static String checkin = '/newWork/';
  static String checkout = '/editWork/';
  static String dashboardData = '/allDashBoard/';
}
